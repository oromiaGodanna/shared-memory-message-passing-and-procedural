/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package squareserverremote;
import java.rmi.*;
import java.rmi.registry.*;

public class SquareClient {

    public static void main(String[] args) {

        System.setSecurityManager(new RMISecurityManager());
        try {
            SquareServerRemote ssr = (SquareServerRemote) Naming.lookup("//hilton:2000/SquareServer");
            int result = ssr.getSquare(6);
            System.out.println("The square of 6 is " + result); 

        } catch(Exception e) {

            e.printStackTrace(); 

        } 

    } 

}