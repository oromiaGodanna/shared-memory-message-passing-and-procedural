/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package squareserverremote;
import java.rmi.*;
import java.rmi.server.*;
import java.rmi.registry.*;
import java.net.*;


/**
 *
 * @author ori
 */
public class SquareServer  extends UnicastRemoteObject implements SquareServerRemote {

        @Override
        public int getSquare(int i) throws RemoteException {

            return i*i; 

        }

        public static void main(String args[]) {

            System.setSecurityManager(new RMISecurityManager());
            try {

                SquareServer me = new SquareServer();
                Naming.bind("//hilton:2000/SquareServer",me); 

            } catch(Exception e) {

                e.printStackTrace(); 

            } 

        } 

    } 


